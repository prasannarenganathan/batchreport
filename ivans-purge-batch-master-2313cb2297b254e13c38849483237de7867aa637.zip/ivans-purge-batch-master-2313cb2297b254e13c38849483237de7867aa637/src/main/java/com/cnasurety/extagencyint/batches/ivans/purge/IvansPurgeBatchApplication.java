package com.cnasurety.extagencyint.batches.ivans.purge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IvansPurgeBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(IvansPurgeBatchApplication.class, args);
	}

}
